let html5QrCode;
const qrRegionId = "reader";

document.addEventListener("DOMContentLoaded", () => {
  const btnQR = document.getElementById("btn-qr");
  const modal = document.getElementById("qr-modal");
  const cerrarBtn = document.getElementById("cerrar-qr");

  btnQR.addEventListener("click", (e) => {
    e.preventDefault();
    modal.style.display = "flex";

    html5QrCode = new Html5Qrcode(qrRegionId);
    html5QrCode.start(
      { facingMode: "environment" },
      {
        fps: 10,
        qrbox: 250
      },
      qrCodeMessage => {
        alert("Código QR detectado: " + qrCodeMessage);
        detenerQR();
      },
      errorMessage => {
        // Errores menores ignorados
      }
    ).catch(err => {
      console.error("Error al iniciar QR: ", err);
    });
  });

  cerrarBtn.addEventListener("click", detenerQR);
});

function detenerQR() {
  const modal = document.getElementById("qr-modal");
  if (html5QrCode) {
    html5QrCode.stop().then(() => {
      html5QrCode.clear();
      modal.style.display = "none";
    }).catch(err => {
      console.error("Error al detener QR: ", err);
    });
  } else {
    modal.style.display = "none";
  }
}
