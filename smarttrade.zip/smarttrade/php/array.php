<?php
$imagenes = [
  1 => ['archivo' => 'inflamables.png', 'ghs' => 'GHS02', 'desc' => 'Inflamable'],
  2 => ['archivo' => 'Toxicidadaguda.png', 'ghs' => 'GHS06', 'desc' => 'Toxicidad aguda'],
  3 => ['archivo' => 'Corrosioncutanea.png', 'ghs' => 'GHS05', 'desc' => 'Corrosivo'],
  4 => ['archivo' => 'comburentes.png', 'ghs' => 'GHS03', 'desc' => 'Comburente'],
  5 => ['archivo' => 'irritacion.png', 'ghs' => 'GHS07', 'desc' => 'Irritante'],
  6 => ['archivo' => 'Peligrosoparaelmedioambienteacuatico.png', 'ghs' => 'GHS09', 'desc' => 'Peligro ambiental'],
  7 => ['archivo' => 'Peligroporaspiracion.png', 'ghs' => 'GHS08', 'desc' => 'Peligro por aspiración'],
  8 => ['archivo' => 'Explosivos.png', 'ghs' => 'GHS01', 'desc' => 'Explosivo'],
  9 => ['archivo' => 'Gasescomprimidos.png', 'ghs' => 'GHS04', 'desc' => 'Gases a presión'],
];

$ghs_indicaciones = [
  1 => ['ghs' => 'GHS02', 'desc' => 'Puede encenderse fácilmente al contacto con una fuente de ignición.'],
  2 => ['ghs' => 'GHS06', 'desc' => 'Tóxico en contacto con la piel o por inhalación.'],
  3 => ['ghs' => 'GHS05', 'desc' => 'Provoca quemaduras graves en piel y ojos.'],
  4 => ['ghs' => 'GHS03', 'desc' => 'Comburente: puede agravar un incendio.'],
  5 => ['ghs' => 'GHS07', 'desc' => 'Puede causar irritación en piel u ojos.'],
  6 => ['ghs' => 'GHS09', 'desc' => 'Peligroso para el medio ambiente acuático.'],
  7 => ['ghs' => 'GHS08', 'desc' => 'Puede causar daños graves a la salud a largo plazo.'],
  8 => ['ghs' => 'GHS01', 'desc' => 'Explosivo incluso sin contacto directo.'],
  9 => ['ghs' => 'GHS04', 'desc' => 'Contiene gases comprimidos o licuados.'],
];

$ghs_indicacionesepp = [
  1 => ['ghs' => 'GHS02', 'desc' => 'Usar guantes resistentes al calor y gafas de seguridad.'],
  2 => ['ghs' => 'GHS06', 'desc' => 'Mascarilla con filtro y guantes impermeables.'],
  3 => ['ghs' => 'GHS05', 'desc' => 'Guantes, gafas protectoras y delantal de PVC.'],
  4 => ['ghs' => 'GHS03', 'desc' => 'Almacenamiento alejado de materiales inflamables.'],
  5 => ['ghs' => 'GHS07', 'desc' => 'Usar gafas, guantes y ropa de manga larga.'],
  6 => ['ghs' => 'GHS09', 'desc' => 'Manipular en zonas ventiladas y evitar derrames.'],
  7 => ['ghs' => 'GHS08', 'desc' => 'Protección respiratoria y ropa de seguridad.'],
  8 => ['ghs' => 'GHS01', 'desc' => 'Pantalla facial, ropa resistente y protección auditiva.'],
  9 => ['ghs' => 'GHS04', 'desc' => 'Usar guantes térmicos y protección facial contra presión.'],
];


?>