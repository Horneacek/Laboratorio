<?php
session_start();
include('conexion.php');

if (!isset($_SESSION['correo'])) {
    header("location:sesion.php");
    exit();
}
 $_SESSION['correo'];
$usuario = $_SESSION['correo'];
// $usuario = $_SESSION['correo']['correo']; 

$consulta_usuario = "SELECT id_usuario FROM usuario WHERE correo = '$usuario'";
$result_usuario = $con->query($consulta_usuario);


if ($result_usuario && $result_usuario->num_rows > 0) {
    $row = $result_usuario->fetch_assoc();
    $id_usuario = $row['id_usuario']; 
// } else {
//     die("El usuario no existe.");
 }


$nombre = $_POST['nombre_sustancia'];
$formula = $_POST['formula'];
$estado = $_POST['est'];
$niveles = isset($_POST['nivelpeligro']) ? $_POST['nivelpeligro'] : []; 
$archivos = $_FILES['archivo'];


$ins = "INSERT INTO sustancias (nombre, formula, estado, id_usuario) VALUES ('$nombre', '$formula', '$estado', '$id_usuario')";
$resultado = $con->query($ins);


if ($resultado) {
    $last_id = $con->insert_id; // Obtener el último id insertado para la sustancia



require_once('../qrcode/phpqrcode-master/qrlib.php');  

//datos para el QR


$contenido_qr = "http://localhost/smarttrade/php/ver_sustancia.php?id=$last_id"; //esta teine que ir para que aya a uno solo

//$contenido_qr = "http://TU_DOMINIO/php/informacion.php?id=$last_id";

//$contenido_qr = "Sustancia: $nombre\nFórmula: $formula\nID: $last_id";

//donde se guarda la imagen QR original

// $nombreArchivoQR = "qr$last_id.png";
// $rutaQR = "../qr/" . $nombreArchivoQR;


$nombreLimpio = preg_replace('/[^a-zA-Z0-9]/', '_', $nombre);
$nombreArchivoQR = "qr_" . $nombreLimpio . "_$last_id.png";
$rutaQR = "../qr/" . $nombreArchivoQR;

// Generar el código QR y guardarlo en la carpeta qr/
QRcode::png($contenido_qr, $rutaQR, QR_ECLEVEL_L, 4);

// Actualizar la tabla sustancias con la ruta del QR generado
$updateQR = "UPDATE sustancias SET codigo_qr = '$rutaQR' WHERE id_sustacia = $last_id";
$con->query($updateQR);





    // Insertar los niveles de peligro si existen
    if (!empty($niveles)) {
        foreach ($niveles as $nivel) {
            // Insertamos en la tabla intermedia "sustancia_peligro"
            $ins_nivel = "INSERT INTO sustancia_peligro (id_sustacia, id_peligro) VALUES ('$last_id', '$nivel')";
            $con->query($ins_nivel);
        }
    }

    // Manejo de archivos (subir los archivos)
    if (!empty($archivos['name'][0])) {
        // Si se subieron archivos
        foreach ($archivos['tmp_name'] as $index => $tmp_name) {
            $nombre_archivo = $archivos['name'][$index];
            $ruta_destino = "../uploads/" . $nombre_archivo; // Asegúrate de tener la carpeta "uploads"

            // Verificamos si el archivo se movió correctamente
            if (move_uploaded_file($tmp_name, $ruta_destino)) {
                // Insertamos la referencia del archivo en la base de datos
                $ins_archivo = "INSERT INTO archivos (id_sustancia, archivo) VALUES ('$last_id', '$ruta_destino')";
                $con->query($ins_archivo);
            }
        }
    }

    echo "Datos insertados correctamente!";
} else {
    echo "Error al insertar los datos: " . $con->error;
}
?>
