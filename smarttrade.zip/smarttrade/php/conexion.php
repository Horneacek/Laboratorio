<?php
$con = new mysqli ("localhost", "root", "", "laboratorio");
?>