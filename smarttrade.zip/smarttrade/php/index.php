<?php
session_start();
include('conexion.php');
if (!isset($_SESSION['correo'])) {
    header("location:sesion.php");
}  $_SESSION['correo'];
//  $usuario = $_SESSION['correo']['correo']; 
$usuario = $_SESSION['correo']; 

// $sel="SELECT * FROM sustancias";
// $resultado=$con->query($sel);
$sel = "SELECT s.id_sustacia, s.nombre AS nombre_sustancia, s.fds, s.codigo_qr, e.nombre AS estado_texto, s.formula, 
  u.nombre AS nombre_profesor FROM sustancias s INNER JOIN usuario u ON s.id_usuario = u.id_usuario
INNER JOIN estado e ON s.estado = e.id_estado";
$resultado=$con->query($sel);
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Smart trade</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="../css/index.css">
</head>
<body>

  <nav class="navbar navbar-expand-lg">
    <div class="container">
      <a class="navbar-brand" href="#">Snovi Lab</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
        data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
           <ul class="navbar-nav align-items-center gap-4">
            <li class="nav-item">
            <a class="nav-link" href="#">Inicio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="formreactivo.php">Registrar sustancia</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="formprofes.php">Registrar profesor</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Escanear QR</a>
          </li>
 <li class="nav-item dropdown">
  <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
    <i class="fas fa-user me-1"></i>
    <strong><?php echo $usuario; ?></strong>
  </a>
  <ul class="dropdown-menu dropdown-menu-end">
    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar sesión</a></li>
  </ul>
</li>
</ul>
</div>
    </div>
  </nav>
  <div class="container mt-5">
  
  <div class="row justify-content-center g-4">

  </div>
</div>
<div class="container mt-5">
  <h2 class="text-center mb-4">Reactivos ingresados por profesores</h2>
  <div class="table-responsive">
    <table class="table table-bordered table-hover text-center align-middle">
      <thead class="table-dark">
        <tr>
          <th>Nombre</th>
          <th>fds</th>
          <th>codigo qr</th>
          <th>estado</th>
          <th>fromula</th>
          <th>profesor</th>
          <th>peligros</th>
     
        </tr>
      </thead>
      <tbody>
       <?php
        while ($fila=$resultado -> fetch_assoc()) {
          $id_sustancia = $fila['id_sustacia'];
         
        $respu_peligros = "SELECT np.nombre FROM sustancia_peligro sp JOIN niveles_peligro np ON sp.id_peligro = np.id_peligro WHERE
         sp.id_sustacia = '$id_sustancia'";
         
        $res_peligros = $con->query($respu_peligros);
        $peligros = [];
        while ($pel = $res_peligros->fetch_assoc()) {
            $peligros[] = $pel['nombre'];
        }

        $peligros_mostr = implode(', ', $peligros);
    ?>
        <tr>
            <td><?php echo $fila['nombre_sustancia'] ?></td>
            <td><?php echo $fila['fds'] ?></td>
           <td>
  <a href="ver_sustancia.php?id=<?php echo $fila['id_sustacia']; ?>">
    <img src="<?php echo $fila['codigo_qr']; ?>" alt="QR" width="80">
    </a>
     <br>
  <a href="<?php echo $fila['codigo_qr']; ?>" download class="btn btn-sm btn-outline-primary mt-2">
    Descargar
  
  </a>
</td>

            <td><?php echo $fila['estado_texto'] ?></td>
            <td><?php echo $fila['formula'] ?></td>
            <td><?php echo $fila['nombre_profesor'] ?></td>
            <td><?php echo $peligros_mostr; ?></td>
            
           
            </tr>
        <?php    
        }
        ?>
      </tbody>
    </table>
  </div>
</div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous">
  </script>
</body>
</html>
