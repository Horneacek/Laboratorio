<?php
 include('conexion.php');

// session_start();

// $correo = $_POST['correo'];
// $contrasena = $_POST['contrasena'];

// $consulta = "SELECT * FROM usuario WHERE correo = '$correo' AND contrasena = '$contrasena'";
// $eje = $con->query($consulta); 

// if ($eje->num_rows > 0) {
//     $datos = $eje->fetch_assoc();

//     $_SESSION['correo'] = $datos;
//     $_SESSION['admins'] = $datos['admins'];

//     if ($datos['admins'] == 1) {
//         header("location:index.php");
//     } else {
//         header("location:../index2.html");
//     }
// } else {
//     echo "Correo o contraseña incorrectos.";
// }

include('conexion.php');
session_start();

$correo = $_POST['correo'] ?? '';
$contrasena = $_POST['contrasena'] ?? '';

$consulta = "SELECT * FROM usuario WHERE correo = '$correo'";
$eje = $con->query($consulta);

if ($eje && $eje->num_rows > 0) {
    $datos = $eje->fetch_assoc();

    if (password_verify($contrasena, $datos['contrasena'])) {
        $_SESSION['correo'] = $datos['correo'];
        $_SESSION['admins'] = $datos['admins'];

        if ($datos['admins'] == 1) {
            header("Location: index.php");
        } else {
            header("Location: ../index2.html");
        }
        exit;
    } else {
        echo "Contraseña incorrecta.";
    }
} else {
    echo "Usuario no encontrado.";
}
?>