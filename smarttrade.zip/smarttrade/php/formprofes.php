<?php
session_start();
include('conexion.php');
if (!isset($_SESSION['correo'])) {
    header("location:sesion.php");
  
}  $_SESSION['correo'];
$usuario = $_SESSION['correo']; 

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Iniciar sesión</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
    <link href="../css/formslogin.css" rel="stylesheet">
    <link href="../css/index.css" rel="stylesheet">
</head>
<body>
 <nav class="navbar navbar-expand-lg fixed-top bg-white shadow-sm">
    <div class="container">
      <a class="navbar-brand" href="#">Snovi Lab</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
        data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav align-items-center gap-4">
            <li class="nav-item">
            <a class="nav-link" href="index.php">Volver</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="formreactivo.php">Registrar sustancias</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Informacion de seguridad</a>
          </li>
         <li class="nav-item">
 <li class="nav-item dropdown">
  <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
    <i class="fas fa-user me-1"></i>
    <strong><?php echo $usuario; ?></strong>
  </a>
  <ul class="dropdown-menu dropdown-menu-end">
    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar sesión</a></li>
  </ul>
</li>

        
        </ul>
      </div>
    </div>
  </nav>
  <div class="formu">
    <h2 class="text-center">Crear cuenta</h2>
    
    <form action="registrarprof.php" method="post">
      <div class="mb-3">
        <label for="usuario" class="form-label">Ingresá nombre</label>
        <input type="text" class="form-control" id="usuario" name="nombre" required>
      </div>
      <div class="mb-3">
        <label for="correo" class="form-label">Ingresá correo electrónico</label>
        <input type="email" class="form-control" id="correo" name="correo" required>
      </div>
      <div class="mb-3">
        <label for="contraseña" class="form-label">Ingresá contraseña</label>
        <input type="password" class="form-control" id="contrasena" name="contrasena" required>
      </div>
      <div class="d-grid">
        <input type="submit" class="btn btn-login" value="Iniciar">
      </div>
    </form>

    
  </div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous">
  </script>
</body>
</html>
