<?php
include("conexion.php");

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id <= 0) {
    echo "ID no válido.";
    exit;
}

$sql = "SELECT s.id_sustacia, s.nombre AS sustancia, s.formula, e.nombre AS estado
        FROM sustancias s
        INNER JOIN estado e ON s.estado = e.id_estado
        WHERE s.id_sustacia = $id";
$resultado = $con->query($sql);

include ("array.php");
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Ficha de sustancia</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="../css/index.css">
  <link rel="stylesheet" href="../css/qr.css">
</head>
<body>

  
  <nav class="navbar navbar-expand-lg fixed-top bg-white shadow-sm">
    <div class="container">
      <a class="navbar-brand" href="#">Gestión de Comercio</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
        data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav align-items-center gap-4">
            <li class="nav-item"><a class="nav-link" href="../index2.html">Inicio</a></li>
            <li class="nav-item"><a class="nav-link" href="#"></a></li>
            <li class="nav-item"><a class="nav-link" href="#">Información de seguridad</a></li>
            <li class="nav-item"><a class="nav-link" href="#" id="btn-qr">Escanear QR</a></li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-user me-1"></i>
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="html/login.html">Iniciar sesión</a></li>
                <li><a class="dropdown-item" href="#">Registrarse</a></li>
              </ul>
            </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container mt-5 pt-5">
  <?php if ($row = $resultado->fetch_assoc()): ?>
    <div class="mx-auto p-4 mb-5 shadow rounded-4 bg-white border" style="max-width: 900px;">
      <h2 class="text-center mb-4">
        <?php echo ucfirst($row['sustancia']); ?> (<strong><?php echo $row['formula']; ?></strong>)
      </h2>

      <div class="row">
        <div class="col-md-12 text-center mb-4">
          <h5><strong>Pictograma</strong></h5>
          <div class="d-flex justify-content-center flex-wrap gap-3">
            <?php
            $id_sustancia = $row['id_sustacia'];
            $q = "SELECT sp.id_peligro FROM sustancia_peligro sp WHERE sp.id_sustacia = $id_sustancia";
            $res_peligros = $con->query($q);
            while ($p = $res_peligros->fetch_assoc()) {
              $id_p = $p['id_peligro'];
              if (isset($imagenes[$id_p])) {
                $img = $imagenes[$id_p];
                echo "<div class='text-center mx-2'>";
                echo "<img src='../imgPictogramas/{$img['archivo']}' alt='Pictograma $id_p' width='80'><br>";
                echo "<small><strong>{$img['ghs']}</strong><br>{$img['desc']}</small>";
                echo "</div>";
              }
            }
            ?>
          </div>
        </div>

        <div class="col-md-12 mb-4">
          <h5><strong>Indicaciones de peligro</strong></h5>
          <ul>
            <?php
            $res_peligros->data_seek(0);
            while ($p = $res_peligros->fetch_assoc()) {
              $id_p = $p['id_peligro'];
              if (isset($ghs_indicaciones[$id_p])) {
                $ghs = $ghs_indicaciones[$id_p];
                echo "<li><strong>{$ghs['ghs']}</strong> {$ghs['desc']}</li>";
              }
            }
            ?>
          </ul>
        </div>

        <div class="text-start d-inline-block">
          <p><strong>➤ Estado físico:</strong> <?php echo $row['estado']; ?></p>
          <p><strong>➤ Riesgo de la salud:</strong> 3 (Muy peligroso)</p>
          <p><strong>➤ Riesgo de inflamabilidad:</strong> 0 (No se inflama)</p>
          <p><strong>➤ Riesgo de reactividad:</strong> 2 (Inestable en caso de cambio químico violento)</p>
          <p><strong>➤ Riesgo específico:</strong> Oxidante</p>
        </div>
      </div>

      <div class="text-center mt-4">
        <a href="informacion.php" class="btn btn-outline-primary"><i class="fas fa-arrow-left me-1"></i>Ver todas las sustancias</a>
      </div>
    </div>
  <?php else: ?>
    <div class="alert alert-danger mt-5">Sustancia no encontrada.</div>
  <?php endif; ?>
</div>

<!-- Modal QR -->
<div id="qr-modal" style="display: none;">
  <div id="qr-box">
    <span id="cerrar-qr">&times;</span>
    <div id="reader" style="width: 300px; height: 300px;"></div>
  </div>
</div>

<script src="https://unpkg.com/html5-qrcode"></script>
<script src="../js/qr.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
