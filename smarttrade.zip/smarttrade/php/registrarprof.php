<?php
include("conexion.php");
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$contrasena = password_hash($_POST['contrasena'], PASSWORD_BCRYPT);




    $verificar = "SELECT correo FROM usuario WHERE correo='$correo'";
    $verificar2=$con->query($verificar);

   
        if ($verificar2->num_rows>0) {
            echo "usuario en uso elige otro";
        }else {
           
    
    $insertar="INSERT INTO usuario (nombre, correo, contrasena, admins) VALUES ('$nombre', '$correo', '$contrasena', 1)";
    $con->query($insertar);
    echo "Registrado correctamente ir a <a href='iniciar.php'>iniciar sesion</a>";
    
}