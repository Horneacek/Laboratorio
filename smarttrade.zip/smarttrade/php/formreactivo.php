<?php
session_start();
include('conexion.php');
if (!isset($_SESSION['correo'])) {
    header("location:sesion.php");
  
}  $_SESSION['correo'];
$usuario = $_SESSION['correo']; 
//$usuario = $_SESSION['usuario']['correo'];



$consultap = "SELECT * FROM niveles_peligro";
$resp = $con->query($consultap);

$consultae = "SELECT * FROM estado";
$respEstado = $con->query($consultae);

 ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Registo de sustancia</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
<link href="../css/formreactivo.css" rel="stylesheet">
<link href="../css/index.css" rel="stylesheet">
  
</head>
<body>
  <nav class="navbar navbar-expand-lg">
    <div class="container">
      <a class="navbar-brand" href="#">Gestión de Comercio</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
        data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
           <ul class="navbar-nav align-items-center gap-4">
            <li class="nav-item">
            <a class="nav-link" href="index.php">Inicio</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="formreactivo.php">Registrar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Escanear QR</a>
          </li>
 <li class="nav-item dropdown">
  <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
    <i class="fas fa-user me-1"></i>
    <strong><?php echo $usuario; ?></strong>
  </a>
  <ul class="dropdown-menu dropdown-menu-end">
    <li><a class="dropdown-item" href="cerrar_sesion.php">Cerrar sesión</a></li>
  </ul>
</li>

        </ul>
      </div>
    </div>
  </nav>

  <div class="formu">
    <h2 class="text-center">Registar sustancia</h2>
    
    <form action="../php/registarreactivo.php" method="post" enctype="multipart/form-data">
      <div class="mb-3">
        <label for="sustancia" class="form-label">Nombre de la sustancia </label>
        <input type="text" class="form-control" id="sustancia"  name="nombre_sustancia" required>
      </div>
      <div class="mb-3">
        <label for="formula" class="form-label">Formula de la sustancia</label>
        <input type="text" class="form-control" id="formula" name="formula" required>
      </div>
      <div class="mb-3">
        <label for="estado" class="form-label">Estado de la sustancia</label>
        <select name="est" id="estado" class="form-select" required> 
                    <option value="0">Selecciona el estado</option>
                    <?php
                    while($datos = $respEstado->fetch_assoc()){
                        echo "<option value='" . $datos["id_estado"] . "'>" . $datos["nombre"] . "</option>";
                    }
                    ?>
                </select>
      </div>
      <div class="mb-3">
       <label class="form-label">Niveles de peligro</label><br>
          <?php
          while($dato = $resp->fetch_assoc()) {
             $id_p = $dato["id_peligro"];
              echo "<div class='form-check form-check-inline'>";
              echo "<input class='form-check-input' type='checkbox' id='$id_p' name='nivelpeligro[]' value='" . $dato["id_peligro"] . "'>";
              echo "<label class='form-check-label' for='$id_p'>" . $dato["nombre"] . "</label>";
              echo "</div>";
          }
          ?>
        </div>
        <br>
       <div class="mb-3">
  <label for="archivo" class="form-label">Adjuntar PDFs o imágenes</label>
  <input type="file" class="form-control" id="archivo" name="archivo[]" accept=".pdf, image/*" multiple >
</div>

       
      <div class="d-grid">
        <input type="submit" class="btn btn-login" value="Iniciar">
      </div>
    </form>

   
  </div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous">
  </script>
</body>
</html>
