<?php
include("conexion.php");

// Consulta general de sustancias
$sql = "SELECT s.id_sustacia, s.nombre AS sustancia, s.formula, e.nombre AS estado
        FROM sustancias s
        INNER JOIN estado e ON s.estado = e.id_estado";
$resultado = $con->query($sql);

// Relación de ID de peligro con imágenes
// $imagenes = [
//   1 => 'inflamables.png', // Inflamable ghs02
//   2 => 'Toxicidadaguda.png', // Toxicidad aguda ghs06
//   3 => 'Corrosioncutanea.png', // Corrosivo ghs05
//   4 => 'comburentes.png', // Comburenteghs03
//   5 => 'irritacion.png', // Irritanteghs07
//   6 => 'Peligrosoparaelmedioambienteacuatico.png', // Peligro ambientalghs09
//   7 => 'Peligroporaspiracion.png', // Peligro por aspiraciónghs08
//   8 => 'Explosivos.png', // Explosivosghs01
//   9 => 'Gasescomprimidos.png', // Gases a presiónghs04
// ];
include ("array.php");


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Smart trade</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-4Q6Gf2aSP4eDXB8Miphtr37CMZZQ5oXLH2yaXMJ2w8e2ZtHTl7GptT4jmndRuHDT" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="../css/index.css">
  <link rel="stylesheet" href="../css/qr.css">
</head>
<body>

 <nav class="navbar navbar-expand-lg fixed-top bg-white shadow-sm">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="#">
      <img src="../imgPictogramas/Toxicidadaguda.png" alt="Logo" width="30" height="30" class="me-2">
      Snovi lab
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
      data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
      aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>


      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav align-items-center gap-4">
            <li class="nav-item"><a class="nav-link" href="../index2.html">Inicio</a></li>
            <li class="nav-item"><a class="nav-link" href="">que puede ser</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Información de seguridad</a></li>
            <li class="nav-item"><a class="nav-link" href="#" id="btn-qr">Escanear QR</a></li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-user me-1"></i>
              </a>
              <ul class="dropdown-menu dropdown-menu-end">
                <li><a class="dropdown-item" href="../html/login.html">Iniciar sesión</a></li>
                <li><a class="dropdown-item" href="../html/registro.html">Registrarse</a></li>
              </ul>
            </li>
        </ul>
      </div>
    </div>
  </nav>

 <div class="container mt-5 pt-5">
  <?php while ($row = $resultado->fetch_assoc()): ?>
    <div class="mx-auto p-4 mb-5 shadow rounded-4 bg-white border" style="max-width: 900px;">
      <h2 class="text-center mb-4">
        <?php echo ucfirst($row['sustancia']); ?> (<strong><?php echo $row['formula']; ?></strong>)
      </h2>

      <div class="row">
        <div class="col-md-12 text-center mb-4">
          <h5><strong>Pictograma</strong></h5>
          <div class="d-flex justify-content-center flex-wrap gap-3">
            <?php
            $id_sustancia = $row['id_sustacia'];
            $q = "SELECT sp.id_peligro FROM sustancia_peligro sp WHERE sp.id_sustacia = $id_sustancia";
            $res_peligros = $con->query($q);
            while ($p = $res_peligros->fetch_assoc()) {
              $id_p = $p['id_peligro'];
              if (isset($imagenes[$id_p])) {
                $img = $imagenes[$id_p];
                echo "<div class='text-center mx-2'>";
                echo "<img src='../imgPictogramas/{$img['archivo']}' alt='Pictograma $id_p' width='80'><br>";
                echo "<small><strong>{$img['ghs']}</strong><br>{$img['desc']}</small>";
                echo "</div>";
              }
            }
            ?>
          </div>
        </div>

        <div class="col-md-12 mb-4">
          <center><h5><strong>Indicaciones de peligro</strong></h5></center>
          <ul>
            <?php
            $res_peligros->data_seek(0);
            while ($p = $res_peligros->fetch_assoc()) {
              $id_p = $p['id_peligro'];
              if (isset($ghs_indicaciones[$id_p])) {
                $ghs = $ghs_indicaciones[$id_p];
                echo "<li><strong>{$ghs['ghs']}</strong> {$ghs['desc']}</li>";
              }
            }
            ?>
          </ul>
        </div>

        <div class="col-md-12 mb-4">
          <center>
          <h5><strong>Elementos de protección personal (EPP)</strong></h5></center>
          <ul>
            <?php
            $res_peligros->data_seek(0);
            while ($p = $res_peligros->fetch_assoc()) {
              $id_p = $p['id_peligro'];
              if (isset($ghs_indicacionesepp[$id_p])) {
                $ghs = $ghs_indicacionesepp[$id_p];
                echo "<li><strong>{$ghs['ghs']}</strong> {$ghs['desc']}</li>";
              }
            }
            ?>
          </ul>
        </div>
      </div>
    </div>
  <?php endwhile; ?>
</div>


  <!-- Modal QR -->
  <div id="qr-modal" style="display: none;">
    <div id="qr-box">
      <span id="cerrar-qr">&times;</span>
      <div id="reader" style="width: 300px; height: 300px;"></div>
    </div>
  </div>

  <script src="https://unpkg.com/html5-qrcode"></script>
  <script src="../js/qr.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
